<?php

echo "<center><br><br><h1>Em breve, um novo sistema de gestão da Next Entregas...</h1></center>";